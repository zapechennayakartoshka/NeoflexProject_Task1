%~d0
cd %~dp0
java -Dtalend.component.manager.m2.repository=%cd%/../lib -Xms256M -Xmx1024M -cp .;../lib/routines.jar;../lib/dom4j-1.6.1.jar;../lib/log4j-1.2.17.jar;../lib/postgresql-42.2.5.jar;../lib/talend_file_enhanced_20070724.jar;../lib/talendcsv.jar;ft_balance_f_loader_0_1.jar;log_etl_writer_0_1.jar; local_project.ft_balance_f_loader_0_1.FT_BALANCE_F_Loader  --context=Default %*