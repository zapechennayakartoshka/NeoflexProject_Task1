%~d0
cd %~dp0
java -Dtalend.component.manager.m2.repository=%cd%/../lib -Xms256M -Xmx1024M -cp .;../lib/routines.jar;../lib/dom4j-1.6.1.jar;../lib/log4j-1.2.17.jar;../lib/postgresql-42.2.5.jar;../lib/talend_file_enhanced_20070724.jar;../lib/talendcsv.jar;md_currency_d_loader_0_1.jar;log_etl_writer_0_1.jar; local_project.md_currency_d_loader_0_1.MD_CURRENCY_D_Loader  --context=Default %*